

public class fraction
{
    int num1 = 0;
    int dem1 = 0;
    int num2 = 0;
    int dem2 = 0;
    int addnum = (num1 * dem2) + (num2 * dem1);
    int adddem = dem1 * dem2;
    int subnum = (num1 * dem2) - (num2 * dem1);
    int subdem = dem1 * dem2;
    int multnum = num1 * num2;
    int multdem = dem1 * dem2;
    int divnum = num1 * dem2;
    int divdem = dem1 * num2;
    String add = "The fractions added is " + addnum + "/" + adddem;
    String sub = "The fractions subrtacted is " + subnum + "/" + subdem;
    String mult = "The fractions multiplied is " + multnum + "/" + multdem;
    String div = "The fractions multiplied is " + divnum + "/" + divdem;
    
    
    }

